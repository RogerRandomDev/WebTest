const maxNum = 1000

function math(){
    let out = Math.round(Math.random()*maxNum)
    out = out*out
    alert(out)
}